In order to add automatic corner extraction functionality to the ocamCalib Matlab toolbox,
please add this folder into the ocamCalib root diretory.
The executables use code from the openCv image processing library, developped by Intel and
then distributed unter the GNU general public licence, see the licence file.
